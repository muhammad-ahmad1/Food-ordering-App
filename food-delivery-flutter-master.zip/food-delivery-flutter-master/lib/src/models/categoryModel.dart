class Category
{
  final String categoryName;
  final String imagePath;
  final int noOfItem;

  Category({this.categoryName,this.imagePath,this.noOfItem});

}